t=int(input("NO of values  "))
p=int(input("Enter length  "))
s=[]
j=0
while(j<t):
  s.append(input())
  j=j+1
final_list = list(filter(lambda x: (len(x)>p) , s)) 
print(final_list)
