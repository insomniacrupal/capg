def find_longest_word(s):
  list=[] 
  for i in s:
      list.append(len(i))
  print ("Maximum length",max(list))

t=int(input("NO of values  "))
s=[]
j=0
while(j<t):
  s.append(input())
  j=j+1
find_longest_word(s)
