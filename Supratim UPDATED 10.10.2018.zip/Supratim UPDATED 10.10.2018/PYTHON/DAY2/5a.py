def filter_long_words(n,s):
  list=[] 
  for i in s:
       if(len(i)>n):
          list.append(i)
  print(list)

t=int(input("NO of values  "))
p=int(input("Enter length  "))
s=[]
j=0
while(j<t):
  s.append(input())
  j=j+1
filter_long_words(p,s)
