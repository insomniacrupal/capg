list=[1,2,3,4]
add=0
mul=1
for item in list:
    add+=item
    mul*=item
print("Sum of all the numbers in the list is ",add)
print("Product of all the numbers in the list is ",mul)
