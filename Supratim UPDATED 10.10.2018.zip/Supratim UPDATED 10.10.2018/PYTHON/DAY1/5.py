str=input("Enter a String : ")
print(str.swapcase())
