def translate(lis):
  dict={"merry":"god", "christmas":"jul", "and":"och", "happy":"gott" ,"new":"nytt","year":"�r"}
  return (dict[lis])
count=int(input("No of inputs :"))
a=list()
for i in range(count):    
    a.append(input())
for i in range(count):
      print(translate(a[i]))
