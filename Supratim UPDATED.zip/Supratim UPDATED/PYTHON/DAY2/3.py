li = ['pgfd','rgd','ofgdgd','grg','r','ad','mesf','fgi','gfdgfdgz']
final_list = list(map(lambda x: len(x) , li)) 
print(li)
print(final_list)
