def max_in_list(s):

return max(s)

i=0

p=int(input(�No of elements : �))

so=[]

while(i<p):

so.append(int(input()))

i=i+1

print(max_in_list(�MAXIMUM VALUE: �,so))
