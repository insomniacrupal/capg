firstname=input("Enter your first name :")
lastname=input("Enter your last name :")
class C:
    def __init__(self,num1,num2):
        self.num1=num1
        self.num2=num2
    def concat(self):
        return (self.num1+self.num2)
wholename= C(num1,num2).concat()
print(wholename)
