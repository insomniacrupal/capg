count=int(input("No of values :"))
  
a=list()
for i in range(count):    
    a.append(int(input()))
print(a)
for i in range(count):
     print(a[i]*'*')
