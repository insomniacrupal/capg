num1=int(input("Enter a value :"))
count=int(input("No of list values :"))
  
a=list()
for i in range(count):    
    a.append(int(input()))
print(a)
i=0
while(i<count):
    
    if(num1==a[i]):
        print("True")
        break
    else:
        i=i+1


if(i==count):
    print("False")
