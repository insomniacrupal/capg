num1=int(input())
num2=int(input())
num3=num1+num2
if(num3>0):
    print(num3,"is positive .")
elif(num3<0):
    print(num3,"is negative .")
else:
    print("The result is zero")
