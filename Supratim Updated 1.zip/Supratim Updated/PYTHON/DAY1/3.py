num1=3
while True:
    data = int(input("Enter the number : "))
    if (num1!=data):
        print("Sorry, Enter again .")
        continue
    else:
        print("Correct!")
        break
